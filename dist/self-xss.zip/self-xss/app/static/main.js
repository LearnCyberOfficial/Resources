function do_something() {
    document.getElementById("description").innerHTML = document.getElementById("payload").value;
}